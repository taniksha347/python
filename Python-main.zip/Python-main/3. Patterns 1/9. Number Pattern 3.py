# @Kunalbhatia-Hub

n=int(input())
for i in range(1,n+1):
    if i==1:
        print("1")
    elif i==2:
        print("11")
    else:
        print("1"+"2"*(i-2)+"1")

# @Kunalbhatia-Hub