# @Kunalbhatia-Hub

n=int(input())
for i in range(n):
    for j in range(n):
        print(n,end="")
    print()

# @Kunalbhatia-Hub