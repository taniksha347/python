# @Kunalbhatia-Hub

n=int(input())
for i in range(n):
    for j in range(i,i*2+1):
        print(chr(65+j),end="")
    print()

# @Kunalbhatia-Hub