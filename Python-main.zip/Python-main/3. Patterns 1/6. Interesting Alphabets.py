# @Kunalbhatia-Hub

n=int(input())
for i in range(n):
    for j in range(i,-1,-1):
        print(chr(65+(n-j-1)),end="")
    print()
        
# @Kunalbhatia-Hub