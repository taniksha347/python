# @Kunalbhatia-Hub

n=int(input())
li=[int(x) for x in input().split()]
summ=0
for i in range(n):
    summ+=li[i]
print(summ)

# @Kunalbhatia-Hub