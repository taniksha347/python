# @Kunalbhatia-Hub

def check(x):
    return x == x[::-1]

x=input()

if check(x):
    print("true")
else:
    print("false")

# @Kunalbhatia-Hub    