# @Kunalbhatia-Hub


from sys import stdin

def removeAllOccurrencesOfChar(string, ch) :
	
	ans=""

	for i in string:
		if i!=ch:
			ans+=i

	return ans


# @Kunalbhatia-Hub