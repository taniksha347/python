# @Kunalbhatia-Hub    


from sys import stdin

def isPermutation(string1, string2) :
    
    str1=list(string1)
    str1.sort()

    str2=list(string2)
    str2.sort()

    return str1==str2


# @Kunalbhatia-Hub    