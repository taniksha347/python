# @Kunalbhatia-Hub

# CODE 1

n=int(input())
print((n*(n+1)//2))

# CODE 1

# ----------------------------

# CODE 2

n=int(input())

summ=0

while n>0:
    summ+=n
    n=n-1

print(summ)

# CODE 2

# @Kunalbhatia-Hub