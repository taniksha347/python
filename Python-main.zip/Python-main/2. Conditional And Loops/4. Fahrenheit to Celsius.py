# @Kunalbhatia-Hub

start = int(input())
end = int(input())
step = int(input())

while(start <=end) :
    c = (start-32)*5/9
    c = int(c)
    print(start, c)
    start = start+step

# @Kunalbhatia-Hub