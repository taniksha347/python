# @Kunalbhatia-Hub

n = 0

while(n!=6):
    n = int(input())

    if(n==1):
        a1 = int(input())
        b1 = int(input())
        print(a1+b1)

    elif(n==2):
        a2 = int(input())
        b2 = int(input())
        print(a2-b2)

    elif(n==3):
        a3 = int(input())
        b3 = int(input())
        print(a3*b3)

    elif(n==4):
        a4 = int(input())
        b4 = int(input())
        x = a4/b4
        x = int(x)
        print(x)

    elif(n==5):
        a5 = int(input())
        b5 = int(input())
        x = a5%b4
        x = int(x)
        print(x)

    elif(n==6):
        False

    else:
        print("Invalid Operation")

# @Kunalbhatia-Hub