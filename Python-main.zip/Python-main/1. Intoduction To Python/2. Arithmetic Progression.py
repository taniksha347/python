# @Kunalbhatia-Hub

a=int(input())
b=int(input())
c=int(input())
print(c-b)

# @Kunalbhatia-Hub