# @Kunalbhatia-Hub

a=int(input())
b=int(input())
c=int(input())
s=a+b+c
print(s/3)

# @Kunalbhatia-Hub