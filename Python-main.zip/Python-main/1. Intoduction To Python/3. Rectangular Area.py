# @Kunalbhatia-Hub

x1=int(input())
y1=int(input())
x2=int(input())
y2=int(input())
print((x2-x1)*(y2-y1))

# @Kunalbhatia-Hub